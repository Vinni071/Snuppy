# Entrega do checkpoint do PG II — 10/10/2026

Autor: Vinicius Rodrigues da Costa
Projeto: Luminthor — linguagem didática Lumi

O arquivo Luminthor_PGII_Checkpoint_2026-10-10.pdf é o texto atualizado do PG.
O restante deste pacote reúne o código-fonte Flutter/Rust, os arquivos editáveis
do TCC e os registros de validação da versão entregue.

Para reproduzir os testes, consulte docs/checkpoint-2026-10-10.md.
Resultado observado em uma cópia limpa: 65 testes Rust e 58 testes Flutter aprovados.
Para compilar ou executar o aplicativo, siga README.md.
Para editar o texto, use TCC_Teorico/Projeto_LaTeX_TCC/trabalho.tex.
Os arquivos de imagens, referências e estilo institucional acompanham os fontes.

A versão tem como base o commit 7c82b871bb2e5f79358bc0c84cf1d5bc3202170d
com as alterações locais documentadas no registro do checkpoint.
SHA256SUMS.txt identifica o conteúdo de cada arquivo incluído. Após extrair o ZIP,
entre nesta pasta e use sha256sum -c SHA256SUMS.txt para conferir os arquivos.

A avaliação com estudantes, as medições de desempenho móvel e a validação em
smartphones físicos permanecem como etapas posteriores descritas no TCC.

Envie o PDF e este pacote ao ambiente da disciplina conforme as orientações do professor.
